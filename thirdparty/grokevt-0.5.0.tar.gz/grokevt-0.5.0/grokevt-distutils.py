# Called from make with appropriate python version

from distutils.core import setup
setup(name='grokevt', version='0.5', package_dir={'':'lib'}, py_modules=['grokevt'])
